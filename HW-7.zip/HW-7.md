

```python
# Dependencies
import tweepy
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Import and Initialize Sentiment Analyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()

# Twitter API Keys
consumer_key = 'ncIYApS06S4k8VpBrqUYOk8wb'
consumer_secret = 'oR5HNsL6twBliSlTLojB8a63jcqh2WnfsCySZ9mzd64voAGrSA'
access_token = '25749595-JC72urBHJsrwxFHRMiRjvayKDJIHQvxbNwzNob6TT'
access_token_secret = '4pH5dgPAXzx3dMP5HMudZzDciv4iVnizYcFXGgT3HnaHQ'

# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
# Target User Accounts
target_user = ("@BBC", "@CBS", "@CNN", "@FoxNews", "@nytimes")
tweet_scores = []
# List for dictionaries of results

tweets_counter = []
compound_tweet = []
username = []

counter = 1

results_list = []
# Loop through each user
for user in target_user:

    # Variables for holding sentiments
    compound_list = []


    # Loop through 10 pages of tweets (total 200 tweets)
    for x in range(1, 2):
        
        # Get all tweets from home feed
        public_tweets = api.user_timeline(user, page=x)

        # Loop through all tweets
        for tweet in public_tweets:

            # Run Vader Analysis on each tweet
            results = analyzer.polarity_scores(tweet["text"])
            compound = results["compound"]
         

            # Add each value to the appropriate list
            compound_list.append(compound)
           

    # Create a dictionaty of results
    user_results = {
        "Username": user,
        "Compound Score": np.mean(compound_list),
    }

    # Append dictionary to list
    results_list.append(user_results)

    # Print the Averages
    print(f"User: {user}")
    print(f"Compound: {np.mean(compound_list):.3f}")
    #print(f"Positive: {np.mean(positive_list):.3f}")
    #print(f"Neutral: {np.mean(neutral_list):.3f}")
    #print(f"Negative: {np.mean(negative_list):.3f}")
```

    User: @BBC
    Compound: 0.229
    User: @CBS
    Compound: 0.329
    User: @CNN
    Compound: -0.104
    User: @FoxNews
    Compound: -0.115
    User: @nytimes
    Compound: 0.074
    


```python
# Create DataFrame from Results List
results_df = pd.DataFrame(results_list).set_index("Username").round(3)
results_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound Score</th>
    </tr>
    <tr>
      <th>Username</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>@BBC</th>
      <td>0.229</td>
    </tr>
    <tr>
      <th>@CBS</th>
      <td>0.329</td>
    </tr>
    <tr>
      <th>@CNN</th>
      <td>-0.104</td>
    </tr>
    <tr>
      <th>@FoxNews</th>
      <td>-0.115</td>
    </tr>
    <tr>
      <th>@nytimes</th>
      <td>0.074</td>
    </tr>
  </tbody>
</table>
</div>




```python
colors = ["black"]
results_df.plot(kind="bar", figsize=(5,4), color=colors)

plt.title("Overall Media Sentiment on Twitter 4/6/18")
plt.xlabel("News Company")
plt.ylabel("Tweet Sentiment score")
plt.show()
```


![png](output_3_0.png)



```python
# Loop through each user
for user in target_user:
    counter = 1
    # Loop through 10 pages of tweets (total 200 tweets)
    for x in range(1, 10):
        
        # Get all tweets from home feed
        public_tweets = api.user_timeline(user, page=x)

        # Loop through all tweets
        for tweet in public_tweets:

            # Run Vader Analysis on each tweet
            results = analyzer.polarity_scores(tweet["text"])
            compound = results["compound"]
            tweets_ago = counter
            # Add each value to the appropriate list
            compound_tweet.append(compound)
            tweets_counter.append(counter)
            username.append(user)
            
            counter += 1
            
    # Create a dictionaty of results
user_results = {
    "Username": username,
    "Compound Score": compound_tweet,
    "Tweets ago": tweets_counter
    }

tweets=pd.DataFrame(user_results)
tweets
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound Score</th>
      <th>Tweets ago</th>
      <th>Username</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.5994</td>
      <td>1</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.0772</td>
      <td>2</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.7184</td>
      <td>3</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.0000</td>
      <td>4</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.0000</td>
      <td>5</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.0000</td>
      <td>6</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.6239</td>
      <td>7</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.4003</td>
      <td>8</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.5411</td>
      <td>9</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.5267</td>
      <td>10</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.5267</td>
      <td>11</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.4404</td>
      <td>12</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.0000</td>
      <td>13</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.0000</td>
      <td>14</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.3400</td>
      <td>15</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.6705</td>
      <td>16</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.0000</td>
      <td>17</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.0000</td>
      <td>18</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>18</th>
      <td>-0.2023</td>
      <td>19</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.6757</td>
      <td>20</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0.0000</td>
      <td>21</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0.0000</td>
      <td>22</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>22</th>
      <td>-0.3252</td>
      <td>23</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0.0000</td>
      <td>24</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>24</th>
      <td>-0.3182</td>
      <td>25</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>25</th>
      <td>0.0000</td>
      <td>26</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>26</th>
      <td>0.0000</td>
      <td>27</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>27</th>
      <td>0.4939</td>
      <td>28</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>28</th>
      <td>0.2500</td>
      <td>29</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>29</th>
      <td>0.0000</td>
      <td>30</td>
      <td>@BBC</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1770</th>
      <td>0.4069</td>
      <td>151</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1771</th>
      <td>-0.2023</td>
      <td>152</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1772</th>
      <td>0.2732</td>
      <td>153</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1773</th>
      <td>-0.0516</td>
      <td>154</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1774</th>
      <td>0.4404</td>
      <td>155</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1775</th>
      <td>0.7535</td>
      <td>156</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1776</th>
      <td>-0.7717</td>
      <td>157</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1777</th>
      <td>-0.7096</td>
      <td>158</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1778</th>
      <td>0.0772</td>
      <td>159</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1779</th>
      <td>0.0000</td>
      <td>160</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1780</th>
      <td>0.0000</td>
      <td>161</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1781</th>
      <td>0.2500</td>
      <td>162</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1782</th>
      <td>0.0000</td>
      <td>163</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1783</th>
      <td>-0.6124</td>
      <td>164</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1784</th>
      <td>-0.1531</td>
      <td>165</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1785</th>
      <td>0.3612</td>
      <td>166</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1786</th>
      <td>-0.1027</td>
      <td>167</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1787</th>
      <td>-0.3182</td>
      <td>168</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1788</th>
      <td>-0.8591</td>
      <td>169</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1789</th>
      <td>0.0000</td>
      <td>170</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1790</th>
      <td>0.0258</td>
      <td>171</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1791</th>
      <td>0.3724</td>
      <td>172</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1792</th>
      <td>0.2732</td>
      <td>173</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1793</th>
      <td>0.4215</td>
      <td>174</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1794</th>
      <td>0.0000</td>
      <td>175</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1795</th>
      <td>-0.3400</td>
      <td>176</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1796</th>
      <td>0.0000</td>
      <td>177</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1797</th>
      <td>0.0000</td>
      <td>178</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1798</th>
      <td>-0.4588</td>
      <td>179</td>
      <td>@nytimes</td>
    </tr>
    <tr>
      <th>1799</th>
      <td>-0.4404</td>
      <td>180</td>
      <td>@nytimes</td>
    </tr>
  </tbody>
</table>
<p>1800 rows × 3 columns</p>
</div>




```python
# Plot Time Between Tweets
user_cnn = tweets[tweets["Username"]== "@CNN"]
user_nytimes = tweets[tweets["Username"]== "@nytimes"]
user_foxnews = tweets[tweets["Username"]== "@FoxNews"]
user_cbs = tweets[tweets["Username"]== "@CBS"]
user_bbc = tweets[tweets["Username"]== "@BBC"]

x_vals = tweets["Tweets ago"]
y_vals = tweets["Compound Score"]

plt.scatter(user_cnn["Tweets ago"], user_cnn["Compound Score"], c="red",
           edgecolor="black", linewidths = 1, marker="o",label="CNN")
plt.scatter(user_nytimes["Tweets ago"], user_nytimes["Compound Score"], c="blue",
           edgecolor="black", linewidths = 1, marker="o",label="CNN")
plt.scatter(user_foxnews["Tweets ago"], user_foxnews["Compound Score"], c="yellow",
           edgecolor="black", linewidths = 1, marker="o",label="CNN")
plt.scatter(user_cbs["Tweets ago"], user_cbs["Compound Score"], c="black",
           edgecolor="black", linewidths = 1, marker="o",label="CNN")
plt.scatter(user_bbc["Tweets ago"], user_bbc["Compound Score"], c="green",
           edgecolor="black", linewidths = 1, marker="o",label="CNN")

plt.title("Sentiment Analysis of Media Tweets 01/07/2018")
plt.xlabel("Tweets Ago")
plt.ylabel("Compound Polarity")
plt.ylim((-1.03,1.03))
plt.xlim((-1,101))
plt.grid(True)

#plt.scatter("user_cnn", "Tweets ago")


plt.show()
```


![png](output_5_0.png)

